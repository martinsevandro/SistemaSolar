#include <GL/glut.h>
#include "imageloader.h"

int bigOrbitActive = 1;//�rbitas maiores
int smallOrbitActive = 1;//�rbitas menores
int moonsActive = 1;//Mostrar sat�lites naturais
int changeCamera = 0;//Mudan�a de c�mera
int zoom = 50;//Proximidade da c�mera
static float factor = 1;//Fator de velocidade

float lightPos[] = { 0.0, 0.0, -75.0, 1.0 }; // Posi��o do ponto de luz
static float spotAngle = 40; // Spotlight cone half-angle.
float spotDirection[] = { 1.0, 0.0, 0.0 }; // Dire��o do ponto de luz
static float spotExponent = 1.0; // Fator de atenua��o


class Planet {
public:
    float radius, distance, orbit, orbitSpeed, axisTilt, axisAni;
    Planet(float _radius, float _distance, float _orbit, float _orbitSpeed, float _axisTilt, float _axisAni) {
        radius = _radius;
        distance = _distance;
        orbit = _orbit;
        orbitSpeed = _orbitSpeed;
        axisTilt = _axisTilt;
        axisAni = _axisAni;
    }
	//Linhas da �rbita
    void drawSmallOrbit(void) {
        glPushMatrix();
			glColor3ub(255, 255, 255);
			glRotatef(90.0, 1.0, 0.0, 0.0);
			glutWireTorus(0.001, distance, 100.0, 100.0);
        glPopMatrix();
    }
	//Gera o sat�lite natural do planeta
    void drawMoon(void) {
        GLUquadricObj* quadric;
        quadric = gluNewQuadric();
        glPushMatrix();
			glColor3ub(255, 255, 255);
			glRotatef(orbit, 0.0, 1.0, 0.0);
			glTranslatef(distance, 0.0, 0.0);
			gluSphere(quadric, radius, 20.0, 20.0);
        glPopMatrix();
    }

};

//Sun, Planets and Stars
Planet sun(10.0, 0, 0, 0, 0, 0);				//Sun
Planet mer(2.0, 14, 0, 4.74, 02.11, 0);		//Mercury
Planet ven(3.0, 22, 0, 3.50, 177.0, 0);		//Venus
Planet ear(4.0, 32, 0, 2.98, 23.44, 0);		//Earth
Planet mar(2.4, 42, 0, 2.41, 25.00, 0);		//Mars
Planet jup(7.0, 56, 0, 1.31, 03.13, 0);		//Jupiter
Planet sat(6.0, 74, 0, 0.97, 26.70, 0);		//Saturn
Planet ura(5.0, 91, 0, 0.68, 97.77, 0);	//Uranus
Planet nep(4.6, 107.2, 0, 0.54, 28.32, 0);	//Neptune
Planet lun(.80, 6, 0, 5.40, 0, 0);			//Luna     (Earth)
Planet pho(.40, 3.6, 0, 2.30, 0, 0);		//Phobos   (Mars)
Planet dei(.48, 4.8, 0, 3.60, 0, 0);		//Deimos   (Mars)
Planet eur(.48, 8, 0, 4.40, 0, 0);			//Europa   (Jupiter)
Planet gan(.48, 9.4, 0, 5.00, 0, 0);		//Ganymede (Jupiter)
Planet cal(.48, 10.6, 0, 2.30, 0, 0);		//Callisto (Jupiter)
Planet tit(.48, 7.4, 0, 2.40, 0, 0);		//Titan	   (Saturn)
Planet puc(.52, 5.8, 0, 7.00, 0, 0);		//Puck	   (Uranus)
Planet tri(.72, 6.4, 0, 3.40, 0, 0);		//Triton   (Neptune)

//Carregar texturas
GLuint loadTexture(Image* image) {
    GLuint textureId;
    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->width, image->height, 0, GL_RGB, GL_UNSIGNED_BYTE, image->pixels);
    return textureId;
}

GLuint sunTexture, merTexture, venTexture, earTexture, marTexture, jupTexture, satTexture, uraTexture, nepTexture, staTexture;

void setup(void) {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glEnable(GL_DEPTH_TEST);

    //Gera��o de texturas
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
	Image* sta = loadBMP("stars.bmp");		staTexture = loadTexture(sta);		delete sta;
	Image* sun = loadBMP("sun.bmp");		sunTexture = loadTexture(sun);		delete sun;
	Image* mer = loadBMP("mercury.bmp");	merTexture = loadTexture(mer);		delete mer;
	Image* ven = loadBMP("venus.bmp");		venTexture = loadTexture(ven);		delete ven;
	Image* ear = loadBMP("earth.bmp");		earTexture = loadTexture(ear);		delete ear;
	Image* mar = loadBMP("mars.bmp");		marTexture = loadTexture(mar);		delete mar;
	Image* jup = loadBMP("jupiter.bmp");	jupTexture = loadTexture(jup);		delete jup;
	Image* sat = loadBMP("saturn.bmp");		satTexture = loadTexture(sat);		delete sat;
	Image* ura = loadBMP("uranus.bmp");		uraTexture = loadTexture(ura);		delete ura;
	Image* nep = loadBMP("neptune.bmp");	nepTexture = loadTexture(nep);		delete nep;

    //Configurando ilumina��o da cena
    glEnable(GL_LIGHTING);
    float lightAmb[] = { 0.0, 0.0, 0.0, 1.0 };
    float lightDifAndSpec[] = { 1.0, 1.0, 1.0, 1.0 };
    float globAmb[] = { 0.5, 0.5, 0.5, 1.0 };
    glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmb);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDifAndSpec);
    glLightfv(GL_LIGHT0, GL_SPECULAR, lightDifAndSpec);
    glEnable(GL_LIGHT0);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, globAmb);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, spotAngle);
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spotDirection);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, spotExponent);
}

//Desenha a trajet�ria das �rbitas
void orbitalTrails(void) {
    glPushMatrix();
		glColor3ub(255, 255, 255);
		glTranslatef(0.0, 0.0, 0.0);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		glutWireTorus(0.001, mer.distance, 100.0, 100.0);
		glutWireTorus(0.001, ven.distance, 100.0, 100.0);
		glutWireTorus(0.001, ear.distance, 100.0, 100.0);
		glutWireTorus(0.001, mar.distance, 100.0, 100.0);
		glutWireTorus(0.001, jup.distance, 100.0, 100.0);
		glutWireTorus(0.001, sat.distance, 100.0, 100.0);
		glutWireTorus(0.001, ura.distance, 100.0, 100.0);
		glutWireTorus(0.001, nep.distance, 100.0, 100.0);
    glPopMatrix();
}

//Redimensionamento de janela
void reshape(GLint w, GLint h) {
	glViewport(0, 0, w, h);
 	glMatrixMode(GL_PROJECTION);
 	glLoadIdentity();
 	glFrustum(-5.0, 5.0, -5.0, 5.0, 5.0, 200.0);
 	glMatrixMode(GL_MODELVIEW);
}

//Captar algumas entradas do teclado
void keyInput(unsigned char key, int x, int y) {
	switch (key) {
	case 27: exit(0); break;//Pressionar esc para fechar a janela
	case 'o': if (smallOrbitActive) smallOrbitActive = 0; else smallOrbitActive = 1; glutPostRedisplay(); break;//'o' ativa as �rbitas menores
	case 'O': if (bigOrbitActive) bigOrbitActive = 0; else bigOrbitActive = 1; glutPostRedisplay(); break; //'O' ativa as �rbitas maiores
	case 'm': if (moonsActive) moonsActive = 0; else moonsActive = 1; glutPostRedisplay(); break; //'m' mostra as luas
	case '1': changeCamera = 0; glutPostRedisplay(); break;//'1' c�mera em perspectiva
	case '2': changeCamera = 1; glutPostRedisplay(); break;//'2' c�mera lateral
	case '3': changeCamera = 2; glutPostRedisplay(); break;//'3' c�mera superior
	case 'f': factor *= 2; glutPostRedisplay; break;//'f' dobra a velocidade de transla��o dos planetas
	case 's': factor /= 2; glutPostRedisplay; break;//'s' divide por 2 a velocidade de transla��o dos planetas
	}
}

//Captar entradas do mouse
void mouseControl(int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)//Bot�o esquerdo do mouse aumenta o zoom
        zoom+=10;
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)//Bot�o direito do mouse diminui o zoom
		zoom-=10;
	glutPostRedisplay();
}
//==================================================================

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	//Diferentes posi��es da c�mera
	if (changeCamera == 0)gluLookAt(0.0, zoom, 50.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	if (changeCamera == 1)gluLookAt(0.0, 0.0, zoom, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	if (changeCamera == 2)gluLookAt(0.0, zoom, 0.00001, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	//�rbitas maiores
	if (bigOrbitActive == 1) orbitalTrails();

	GLUquadric* quadric;
	quadric = gluNewQuadric();

	//Sol
	glPushMatrix();
	glRotatef(sun.orbit, 0.0, 1.0, 0.0);
	glTranslatef(sun.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(sun.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(sun.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, sunTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, sun.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//Merc�rio
	glPushMatrix();
	glRotatef(mer.orbit, 0.0, 1.0, 0.0);
	glTranslatef(mer.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(mer.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(mer.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, merTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, mer.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//V�nus
	glPushMatrix();
	glRotatef(ven.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ven.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(ven.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ven.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, venTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ven.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glPopMatrix();

	//Planeta Terra, �rbita e lua
	glPushMatrix();
	glRotatef(ear.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ear.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(ear.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ear.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, earTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ear.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	if (smallOrbitActive == 1) {
		lun.drawSmallOrbit(); //Desenha a �rbita da lua
	}
	if (moonsActive == 1) {
		lun.drawMoon(); //Desenha a lua
	}
	glPopMatrix();

	//Marte, �rbita e sat�lite natural
	glPushMatrix();
	glRotatef(mar.orbit, 0.0, 1.0, 0.0);
	glTranslatef(mar.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(mar.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(mar.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, marTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, mar.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	if (smallOrbitActive == 1) {
		pho.drawSmallOrbit();
		dei.drawSmallOrbit();
	}
	if (moonsActive == 1) {
		pho.drawMoon();
		dei.drawMoon();
	}
	glPopMatrix();

	//J�piter, �rbita e sat�lite natural
	glPushMatrix();
	glRotatef(jup.orbit, 0.0, 1.0, 0.0);
	glTranslatef(jup.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(jup.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(jup.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, jupTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, jup.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	if (smallOrbitActive == 1) {
		eur.drawSmallOrbit();
		gan.drawSmallOrbit();
		cal.drawSmallOrbit();
	}
	if (moonsActive == 1) {
		eur.drawMoon();
		gan.drawMoon();
		cal.drawMoon();
	}
	glPopMatrix();

	//Saturno, �rbita e sat�lite natural
	glPushMatrix();
	glRotatef(sat.orbit, 0.0, 1.0, 0.0);
	glTranslatef(sat.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(sat.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(sat.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, satTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, sat.radius, 20.0, 20.0);
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glColor3ub(158, 145, 137);
	glRotatef(-63.0, 1.0, 0.0, 0.0);
	glutWireTorus(0.2, 6.0, 30.0, 30.0);//An�is de saturno
	glutWireTorus(0.4, 5.0, 30.0, 30.0);//An�is de saturno
	glPopMatrix();
	if (smallOrbitActive == 1) {
		tit.drawSmallOrbit();
	}
	if (moonsActive == 1) {
		tit.drawMoon();
	}
	glPopMatrix();

	glColor3ub(255, 255, 255);		//FIXES SHADING ISSUE

	//Urano, �rbita e sat�lite natural
	glPushMatrix();
	glRotatef(ura.orbit, 0.0, 1.0, 0.0);
	glTranslatef(ura.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(ura.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(ura.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, uraTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, ura.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	if (smallOrbitActive == 1) {
		puc.drawSmallOrbit();
	}
	if (moonsActive == 1) {
		puc.drawMoon();
	}
	glPopMatrix();

	//Netuno, �rbita e sat�lite natural
	glPushMatrix();
	glRotatef(nep.orbit, 0.0, 1.0, 0.0);
	glTranslatef(nep.distance, 0.0, 0.0);
	glPushMatrix();
	glRotatef(nep.axisTilt, 1.0, 0.0, 0.0);
	glRotatef(nep.axisAni, 0.0, 1.0, 0.0);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, nepTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	gluQuadricTexture(quadric, 1);
	gluSphere(quadric, nep.radius, 20.0, 20.0);
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	if (smallOrbitActive == 1) {
		tri.drawSmallOrbit();
	}
	if (moonsActive == 1) {
		tri.drawMoon();
	}
	glPopMatrix();

	//Skybox
	glPushMatrix();
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, staTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glBegin(GL_POLYGON);
	glTexCoord2f(-1.0, 0.0); glVertex3f(-200, -200, -100);
	glTexCoord2f(2.0, 0.0); glVertex3f(200, -200, -100);
	glTexCoord2f(2.0, 2.0); glVertex3f(200, 200, -100);
	glTexCoord2f(-1.0, 2.0); glVertex3f(-200, 200, -100);
	glEnd();

	glBindTexture(GL_TEXTURE_2D, staTexture);
	glBegin(GL_POLYGON);
	glTexCoord2f(0.0, 0.0); glVertex3f(-200, -83, 200);
	glTexCoord2f(8.0, 0.0); glVertex3f(200, -83, 200);
	glTexCoord2f(8.0, 8.0); glVertex3f(200, -83, -200);
	glTexCoord2f(0.0, 8.0); glVertex3f(-200, -83, -200);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glPopMatrix();
	glutSwapBuffers();
}

//Transla��o dos planetas
void TimerFunction(int value) {
	mer.orbit += mer.orbitSpeed*factor;
    if (mer.orbit >= 360) mer.orbit = 0;
	ven.orbit += ven.orbitSpeed * factor;
	if (ven.orbit >= 360) ven.orbit = 0;
	ear.orbit += ear.orbitSpeed * factor;
	if (ear.orbit >= 360) ear.orbit = 0;
	mar.orbit += mar.orbitSpeed * factor;
	if (mar.orbit >= 360) mar.orbit = 0;
	jup.orbit += jup.orbitSpeed * factor;
	if (jup.orbit >= 360) jup.orbit = 0;
	sat.orbit += sat.orbitSpeed * factor;
	if (sat.orbit >= 360) sat.orbit = 0;
	ura.orbit += ura.orbitSpeed * factor;
	if (ura.orbit >= 360) ura.orbit = 0;
	nep.orbit += nep.orbitSpeed * factor;
	if (nep.orbit >= 360) nep.orbit = 0;
	lun.orbit += lun.orbitSpeed * factor;
	if (lun.orbit >= 360) lun.orbit = 0;
	pho.orbit += pho.orbitSpeed * factor;
	if (pho.orbit >= 360) pho.orbit = 0;
	dei.orbit += dei.orbitSpeed * factor;
	if (dei.orbit >= 360) dei.orbit = 0;
	eur.orbit += eur.orbitSpeed * factor;
	if (eur.orbit >= 360) eur.orbit = 0;
	gan.orbit += gan.orbitSpeed * factor;
	if (gan.orbit >= 360) gan.orbit = 0;
	cal.orbit += cal.orbitSpeed * factor;
	if (cal.orbit >= 360) cal.orbit = 0;
	tit.orbit += tit.orbitSpeed * factor;
	if (tit.orbit >= 360) tit.orbit = 0;
	puc.orbit += puc.orbitSpeed * factor;
	if (puc.orbit >= 360) puc.orbit = 0;
	tri.orbit += tri.orbitSpeed * factor;
	if (tri.orbit >= 360) tri.orbit = 0;

	mer.axisAni += 10.0;
	if (mer.axisAni > 360.0) mer.axisAni -= 360.0;
	ven.axisAni += 10.0;
	if (ven.axisAni > 360.0) ven.axisAni -= 360.0;
	ear.axisAni += 10.0;
	if (ear.axisAni > 360.0) ear.axisAni -= 360.0;
	mar.axisAni += 10.0;
	if (mar.axisAni > 360.0) mar.axisAni -= 360.0;
	jup.axisAni += 10.0;
	if (jup.axisAni > 360.0) jup.axisAni -= 360.0;
	sat.axisAni += 10.0;
	if (sat.axisAni > 360.0) sat.axisAni -= 360.0;
	ura.axisAni += 10.0;
	if (ura.axisAni > 360.0) ura.axisAni -= 360.0;
	nep.axisAni += 10.0;
	if (nep.axisAni > 360.0) nep.axisAni -= 360.0;

    glutPostRedisplay();
    glutTimerFunc(33, TimerFunction, 1);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Sistema Solar");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouseControl);
	glutKeyboardFunc(keyInput);
    glutTimerFunc(100, TimerFunction, 0);
    glEnable(GL_DEPTH_TEST);
	setup();
    glutMainLoop();
}